import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import chartData from "./dummyData.json";

const Chart = () => {
  return (
    <div>
      <center>
        {" "}
        <h2>Price Chart Component</h2>
      </center>

      <LineChart width={800} height={400} data={chartData.chartData}>
        <XAxis dataKey="time" />
        <YAxis />
        <CartesianGrid stroke="#f5f5f5" />
        <XAxis dataKey="name" tick={{ fontSize: 20 }} />
        <YAxis tick={{ fontSize: 20 }} />
        <Line
          type="monotone"
          dataKey="price"
          stroke="#ff7300"
          activeDot={{ r: 8 }}
        />
        <Tooltip />
      </LineChart>
    </div>
  );
};

export default Chart;
