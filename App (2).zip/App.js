import React from "react";
import Header from "./Header";
import Chart from "./Chart";
import OrderBook from "./OrderBook";
import TradeHistory from "./TradeHistory";
import "./App.css";
import logo from "./logo.jpg";

const App = () => {
  return (
    <div className="container">
      <div className="content-container">
        <div className="order-book-container">
          <img src={logo} alt="Logo" className="logo-image" />
          <OrderBook />
        </div>
        <h3 span className="bold-white">
          TRADE
        </h3>
        <div className="chart-container">
          <Header />
          <Chart />
        </div>
        <div className="trade-history-container">
          <TradeHistory />
        </div>
        <h3>Institution? CoinBase Exchange</h3>
        <div className="App">
          <header className="App-header">
            <div className="button-group">
              <button className="login-button">LOG IN</button>
              <button className="get-started-button">GET STARTED</button>
            </div>
          </header>
          <div className="chart-container">{/* Chart Component */}</div>

          <div className="open-orders-container">
            <h2 className="open-orders">Open Orders</h2>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
