import React from "react";

const Header = () => {
  return (
    <div className="header">
      <center>
        <center>
          <h1>
            <u>
              <mark>COINBASE PRO TRADE</mark>
            </u>
          </h1>
        </center>
      </center>
      <br></br>
      <br></br>
      <br></br>
    </div>
  );
};

export default Header;
