import React from "react";
import tradeHistoryData from "./dummyData.json";

const TradeHistory = () => {
  return (
    <div>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <h2>Trade History Component</h2>
      <table className="trade-history">
        <thead>
          <tr>
            <th>Time</th>
            <th>Price(USD)</th>
            <th>Trade Size</th>
          </tr>
        </thead>

        <tbody>
          {tradeHistoryData.tradeHistory.map((item, index) => (
            <tr key={index}>
              <td>{item.time}</td>
              <td>{item.price}</td>
              <td>{item.amount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TradeHistory;
