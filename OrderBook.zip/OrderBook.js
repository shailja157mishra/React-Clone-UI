import React from "react";
import orderData from "./dummyData.json";

const OrderBook = () => {
  const orderBookStyle = {
    marginTop: "150px",
    marginRight: "20px",
  };

  const tableStyle = {
    width: "100%",
    borderCollapse: "collapse",
    marginBottom: "20px",
  };

  const thStyle = {
    backgroundColor: "lightgreen",
    color: "black",
    padding: "10px",
    textAlign: "left",
    fontWeight: "bold",
  };
  const getOrderBookItemColor = (amount) => {
    if (amount > 3) {
      return "green"; // Apply green color if amount > 3
    } else if (amount < 2) {
      return "red"; // Apply red color if amount < 2
    } else {
      return "white"; // Apply white color for other amounts
    }
  };

  const tdStyle = {
    padding: "10px",
  };

  const priceColStyle = {
    paddingRight: "10px",
  };

  const amountColStyle = {
    paddingLeft: "10px",
  };
  return (
    <div className="order-book" style={orderBookStyle}>
      <h2>Order Book Component</h2>
      <table style={tableStyle}>
        <thead>
          <tr>
            <th style={thStyle}>Market Size</th>
            <th style={{ ...thStyle, ...amountColStyle }}>Price(USD)</th>
            <th style={{ ...thStyle, ...amountColStyle }}>USD Spread</th>
          </tr>
        </thead>
        <tbody>
          {orderData.orderbook.map((item, index) => (
            <tr key={index}>
              <td style={{ ...tdStyle, ...priceColStyle }}>{item.price}</td>
              <td style={{ ...tdStyle, ...amountColStyle }}>{item.amount}</td>
              <td style={{ color: getOrderBookItemColor(item.amount) }}>
                {item.amount}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OrderBook;
